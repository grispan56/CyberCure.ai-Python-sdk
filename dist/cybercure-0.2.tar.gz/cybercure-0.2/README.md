Cybercure.ai SDK allows quick and easy access to cybercure public data.
there are several calls available

* get_hash_indicators()
* get_ip_indictors
* get_url_indicators

Checkout the documentation at:

for more details and parameters that can be used.
Feel free to fork and suggest improvments.
